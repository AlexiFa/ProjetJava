Mele-Mele Island

Membres : Vinciane Loy, Marion Galfard, Rebecca Morel, Romain Léoture, Alexis Faure

Étapes d'execution :
Executer la classe "Main.java"
Pour tester les fonctionnalités, des menus indiques les actions disponibles avec un chiffre donné pour chaque fonctionnalité.
Entrez le chiffre correspondant à la fonctionnalitéde votre choix et laissez vous guider par l'affichage console.

Cette version est la version finale bien que rendu un peu en retard. Toutes nos excuses pour ce contre temps 